<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\WePayController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CardHolderController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/onboarding', function () {
    return view('onboarding');
});


Route::get('/m', function () {
    return view('m');
});



Route::get('/banking', function () {
    return view('banking');
});


Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';




Route::get('/create-legal-entity', function () {
    return view('createLegalEntity');
});

Route::post('/create-legal-entity', [WePayController::class, 'createMerchant'])->name('legal-entity.store');


Route::get('/cardholder/registration', function () {
    return view('cardholder.registration');
});

Route::post('/cardholder/create', [CardHolderController::class, 'create'])->name('cardholder.create');

Route::post('/cardholder/{cardHolderId}/create-card', [CardHolderController::class, 'createCard'])->name('cardholder.createCard');


// Display the registration form
Route::get('/cardholder/registration', function () {
    return view('cardholder.registration');
})->name('cardholder.registration');

// Handle card holder creation
Route::post('/cardholder/create', [CardHolderController::class, 'create'])->name('cardholder.create');

// Handle card creation
Route::post('/card/create/{id}', [CardHolderController::class, 'createCard'])->name('card.create');




<?php

namespace App\Models;

class Legal extends Model // Assuming Legal extends Eloquent\Model
{
    // Define the fillable fields for mass assignment
    protected $fillable = [
        'legal_entity_id',
        'terms_of_service_acceptance_time',
        'terms_of_service_original_ip',
        // Add other fields here...
    ];
}

// In your controller or script:

use App\Models\Legal;

// JSON data from your question
$jsonData;

// Create a new Legal model instance and fill it with data
$legal = new Legal([
    'legal_entity_id' => $jsonData['id'],
    'terms_of_service_acceptance_time' => $jsonData['terms_of_service']['acceptance_time'],
    'terms_of_service_original_ip' => $jsonData['terms_of_service']['original_ip'],
    // Set all other fields here...
]);

// Save the Legal model to the database
$legal->save();

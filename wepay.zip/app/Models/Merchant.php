<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Merchant extends Model
{
    use HasFactory;

    protected $table = 'merchants';

    protected $fillable = [
           'legal_id',  ''
        // Add fillable attributes for additional representatives if needed
    ];


    // If you have JSON fields, you can cast them as arrays
    protected $casts = [
        'address' => 'json',
        'entity_country_info' => 'json',
        'controller' => 'json',
        'additional_representatives' => 'json',
    ];

    // You can define relationships with other models here if needed
}

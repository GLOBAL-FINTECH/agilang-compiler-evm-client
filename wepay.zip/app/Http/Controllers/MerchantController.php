<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class WePayController extends Controller
{
    public function createLegalEntity(Request $request)
    {
        // Replace with your actual App-Id and App-Token
        $appId = '{Your-App-Id}';
        $appToken = '{Your-App-Token}';
        
        $requestData = [
            "country" => $request->input('country'),
            "address" => [
                "city" => $request->input('address_city'),
                "country" => $request->input('address_country'),
                "line1" => $request->input('address_line1'),
                "postal_code" => $request->input('address_postal_code'),
                "region" => $request->input('address_region'),
            ],
            "entity_name" => $request->input('entity_name'),
            "primary_url" => $request->input('primary_url'),
            "entity_country_info" => [
                "country_of_formation" => $request->input('entity_country_of_formation'),
                "operates_in_sanctioned_countries" => [],
                "year_of_formation" => $request->input('entity_year_of_formation'),
                "US" => [
                    "employer_identification_number" => $request->input('entity_EIN'),
                    "legal_form" => $request->input('entity_legal_form'),
                ],
            ],
            "controller" => [
                "address" => [
                    "city" => $request->input('controller_address_city'),
                    "country" => $request->input('controller_address_country'),
                    "line1" => $request->input('controller_address_line1'),
                    "postal_code" => $request->input('controller_address_postal_code'),
                    "region" => $request->input('controller_address_region'),
                ],
                "date_of_birth" => [
                    "day" => $request->input('controller_dob_day'),
                    "month" => $request->input('controller_dob_month'),
                    "year" => $request->input('controller_dob_year'),
                ],
                "email" => $request->input('controller_email'),
                "email_is_verified" => true,
                "name" => [
                    "first" => $request->input('controller_first_name'),
                    "last" => $request->input('controller_last_name'),
                ],
                "personal_country_info" => [
                    "US" => [
                        "social_security_number" => $request->input('controller_SSN'),
                    ],
                ],
                "phone" => [
                    "country_code" => $request->input('controller_phone_country_code'),
                    "phone_number" => $request->input('controller_phone_number'),
                ],
                "job_title" => $request->input('controller_job_title'),
                "is_beneficial_owner" => $request->input('controller_is_beneficial_owner'),
            ],
            "additional_representatives" => [
                "representative_{X}" => [], // Fill in the representative data as needed
            ],
        ];

        $response = Http::withHeaders([
            'App-Id' => $appId,
            'App-Token' => $appToken,
            'Accept' => 'application/json',
            'Api-Version' => '3.0',
            'Content-Type' => 'application/json',
        ])->post('https://stage-api.wepay.com/legal_entities', $requestData);

        // Handle the response as needed (e.g., validation, error handling, etc.)
        $responseData = $response->json();

        // Return the response or perform any necessary actions
        return response()->json($responseData);
    }
}

<?php
namespace App\Http\Controllers;
use App\Http\Requests\LegalRequest;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use GuzzleHttp\Client;
use App\Models\Merchant; // Import your Merchant model
use App\Models\Legal;
use App\Models\User; //
class WePayController extends Controller
{
    public function createMerchant(Request $request)
    {
        // WePay API URL
        $url = 'https://stage-api.wepay.com/legal_entities';

        // app id and token
        $appId = env('APP_ID');
        $appToken = env('APPTOKEN');

        // Validate the form data

        // 'address.city' => 'required|string',
        // 'address.line1' => 'required|string',
        // 'address.postal_code' => 'required|string',
        // 'address.region' => 'required|string',
        // 'entity_name' => 'required|string',
        // 'primary_url' => 'nullable|string',
        // 'entity_country_info.country_of_formation' => 'required|string',
        // 'entity_country_info.year_of_formation' => 'required|integer',
        // 'entity_country_info.US.employer_identification_number' => 'nullable|string',
        // 'entity_country_info.US.legal_form' => 'required|string',
        // 'controller.address.city' => 'required|string',
        // 'controller.address.country' => 'required|string',
        // 'controller.date_of_birth' => 'required|date',
        // 'controller.email' => 'nullable|email',
        // 'controller.email_is_verified' => 'nullable|boolean',
        // 'controller.name.first' => 'required|string',
        // 'controller.name.last' => 'required|string',
        // 'controller.personal_country_info.US.social_security_number' => 'nullable|string',
        // 'controller.phone.country_code' => 'nullable|string',
        // 'controller.phone.phone_number' => 'nullable|string',
        // 'controller.job_title' => 'required|string',
        // 'controller.is_beneficial_owner' => 'nullable|boolean',
        $validata = $request->validate([
            // Add validation rules for each field
            'country' => 'required|string',
             'controller' => [
                "email" => ['required ', 'email']
             ]
            // Add validation rules for additional representatives if needed
        ]);



        // Prepare the data to send to WePay API
        $data = [
            'country' => $request->country,
            'controller' => [
                'email' => $request->controller_email
                ]];

        // Create a Guzzle HTTP client
        $client = new Client();

        try {
            // Send a POST request to WePay API
            $response = $client->post($url, [
                'headers' => [
                    'App-Id' => $appId,
                    'App-Token' => $appToken,
                    'Accept' => 'application/json',
                    'Api-Version' => '3.0',
                    'Content-Type' => 'application/json',
                ],
                'json' => $data,
            ]);
        
            // Get the response body as JSON
            $responseData = json_decode($response->getBody());
        
            // Handle the response as needed
            if ($response->getStatusCode() === 200) {
                // Create a new instance of the Legal model
                $legal = new Legal();
        
                // Save the Legal model to the database
                $legal->save();
        
                {
                    // Validation passed, create a new Legal record
                    $legal = new Legal();
                    $legal->legal_entity_id = $request->input('legal_entity_id');
                    $legal->name = $request->input('name');
                    $legal->description = $request->input('description');
                    $legal->save();
            
                    // You can also associate an industry with the legal record
                    $industryData = [
                        'merchant_category_code' => $request->input('industry.merchant_category_code')
                    ];
            
                    $legal->industry()->create($industryData);
            
                    // Redirect or respond with success message here
                }
            
           
            
            }
        
            // Return the API response
            return response()->json($responseData);

            if ($apiResponse->successful()) {
                // 2. Insert the response data into the database
                $responseData = $apiResponse->json();
                $legal = new Legal();
                $legal->legal_entity_id = $responseData['legal_entity_id'];
                
                // Populate the Legal model with data from the JSON response
                $legal->legal_entity_id = $responseData->id;
                $legal->terms_of_service_acceptance_time = $responseData->terms_of_service->acceptance_time;
                $legal->terms_of_service_original_ip = $responseData->terms_of_service->original_ip;
                // Set other fields based on the JSON response

                $legal->save();
    
                // 3. Return the API response as a JSON response
                return response()->json($responseData);



                
            } else {
                // Handle the case where the API request was not successful
                return response()->json(['error' => 'API request failed'], 500);
            }
        
        } catch (\Exception $e) {
            // Handle exceptions here
            // You can return an error response or log the error
            return response()->json(['error' => 'Failed to create a legal entity.']);
        }

    }

}


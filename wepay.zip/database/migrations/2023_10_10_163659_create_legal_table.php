<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLegalTable extends Migration
{
    public function up()
    {
        Schema::create('legal', function (Blueprint $table) {
            $table->id();
            $table->string('legal_entity_id');
            $table->string('terms_of_service_acceptance_time')->nullable();
            $table->string('terms_of_service_original_ip')->nullable();
            $table->string('controller_type');
            $table->boolean('controller_is_beneficial_owner')->nullable();
            $table->string('controller_name')->nullable();
            $table->string('controller_phone')->nullable();
            $table->string('controller_address')->nullable();
            $table->string('controller_email')->nullable();
            $table->boolean('controller_email_is_verified')->default(false);
            $table->boolean('controller_personal_ssn_last_four_is_present')->default(false);
            $table->boolean('controller_personal_ssn_is_present')->default(false);
            $table->string('controller_job_title')->nullable();
            $table->boolean('controller_date_of_birth_is_present')->default(false);
            $table->string('account_controller')->nullable();
            $table->string('entity_name')->nullable();
            $table->string('phone')->nullable();
            $table->string('primary_url')->nullable();
            $table->string('preferred_locale')->nullable();
            $table->string('description')->nullable();
            $table->string('address')->nullable();
            $table->string('entity_country_info_legal_form')->nullable();
            $table->string('entity_country_info_employer_identification_number')->nullable();
            $table->string('entity_country_info_country_of_formation')->nullable();
            $table->boolean('entity_country_info_operates_in_sanctioned_countries')->nullable();
            $table->string('entity_country_info_year_of_formation')->nullable();
            $table->text('additional_representatives')->nullable();
            $table->text('custom_data')->nullable();
            $table->text('significant_donors')->nullable();
            $table->text('significant_beneficiaries_entities')->nullable();
            $table->text('significant_beneficiaries_geographies')->nullable();
            $table->text('significant_beneficiaries_affiliations')->nullable();
            $table->text('significant_beneficiaries_non_domestic_location_beneficiaries')->nullable();
            $table->boolean('public_ownership_is_publicly_traded')->default(false);
            $table->boolean('public_ownership_is_subsidiary')->default(false);
            $table->string('public_ownership_parent_company_name')->nullable();
            $table->string('public_ownership_primary_exchange')->nullable();
            $table->json('public_ownership_traded_exchanges')->nullable();
            $table->string('annual_sales_volume')->nullable();
            $table->string('annual_sales_volume_currency')->nullable();
            $table->string('average_ticket_size')->nullable();
            $table->string('non_delivery_days')->nullable();
            $table->string('country');
            $table->unsignedBigInteger('create_time');
            $table->string('owner_id');
            $table->timestamps();

            $table->index(['legal_entity_id', 'owner_id']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('legal');
    }
}

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMerchantsTable extends Migration
{
    public function up()
    {
        Schema::create('merchants', function (Blueprint $table) {
            $table->id();
            $table->string('country');
            $table->string('address_city');
            $table->string('address_line1');
            $table->string('address_postal_code');
            $table->string('address_region');
            $table->string('entity_name');
            $table->string('primary_url')->nullable();
            $table->string('country_of_formation');
            $table->integer('year_of_formation');
            $table->string('employer_identification_number')->nullable();
            $table->string('legal_form');
            $table->string('controller_city');
            $table->string('controller_country');
            $table->date('controller_date_of_birth');
            $table->string('controller_email')->nullable();
            $table->boolean('controller_email_is_verified')->nullable();
            $table->string('controller_name_first');
            $table->string('controller_name_last');
            $table->string('controller_ssn')->nullable();
            $table->string('controller_phone_country_code')->nullable();
            $table->string('controller_phone_phone_number')->nullable();
            $table->string('controller_job_title');
            $table->boolean('controller_is_beneficial_owner')->nullable();
            // Add columns for additional representatives if needed
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('merchants');
    }
}
